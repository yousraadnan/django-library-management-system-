from django.contrib import admin
from .models import Book  # Make sure to import your model

admin.site.register(Book)

# Register your models here.
